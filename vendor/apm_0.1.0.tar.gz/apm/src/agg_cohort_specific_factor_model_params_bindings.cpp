#include <RcppArmadillo.h>
#include <unordered_map>
#include <string>
#include <set>
#include "r_utils.h"
#include "cohort_specific_estimates_helpers.h"
#include "core/agg_cohort_specific_factor_model_params.h"

// [[Rcpp::depends(RcppArmadillo)]]

using apm::r_utils::make_xptr;

//------------------------------------------------------------------------------
// Aggregators
//------------------------------------------------------------------------------

// [[Rcpp::export]]
SEXP aggregate_factor_model_params_cpp(
    Rcpp::List per_cohort_factor_estimates_xptrs,
    Rcpp::List observed_outcome_indices, // 1-based
    SEXP cohort_weights_xptr) {

    std::vector<apm::FactorModelEstimates> vec;
    vec.reserve(per_cohort_factor_estimates_xptrs.size());
    for (int i = 0; i < per_cohort_factor_estimates_xptrs.size(); ++i) {
        Rcpp::XPtr<apm::FactorModelEstimates> xp(per_cohort_factor_estimates_xptrs[i]);
        vec.push_back(*xp);
    }

    apm::ObservedOutcomeIndices obs_idx = apm::r_utils::to_cpp_observed_outcome_indices(observed_outcome_indices);
    Rcpp::XPtr<apm::CohortWeightEstimates> wptr(cohort_weights_xptr);
    apm::FactorModelEstimates out = apm::aggregate_cohort_specific_factor_model_params(
        vec, obs_idx, *wptr);
    return make_xptr(std::move(out));
}

// [[Rcpp::export]]
Rcpp::List aggregate_factor_model_params_by_spec_cpp(
    Rcpp::List cohort_specific_factor_ests, // named list: each value is list of XPtr<FactorModelEstimates>
    Rcpp::List observed_outcome_indices,    // 1-based
    Rcpp::List cohort_weights_by_spec       // named list: each value is XPtr<CohortWeightEstimates>
) {
    // Build factor map
    std::unordered_map<std::string, std::vector<apm::FactorModelEstimates>> fact_map;
    {
        Rcpp::CharacterVector nms = cohort_specific_factor_ests.names();
        for (int i = 0; i < cohort_specific_factor_ests.size(); ++i) {
            std::string key = Rcpp::as<std::string>(nms[i]);
            Rcpp::List per_cohort = cohort_specific_factor_ests[i];
            std::vector<apm::FactorModelEstimates> vec;
            vec.reserve(per_cohort.size());
            for (int j = 0; j < per_cohort.size(); ++j) {
                Rcpp::XPtr<apm::FactorModelEstimates> xp(per_cohort[j]);
                vec.push_back(*xp);
            }
            fact_map.emplace(std::move(key), std::move(vec));
        }
    }

    // Build weight map
    std::unordered_map<std::string, apm::CohortWeightEstimates> w_map;
    {
        Rcpp::CharacterVector nms = cohort_weights_by_spec.names();
        for (int i = 0; i < cohort_weights_by_spec.size(); ++i) {
            std::string key = Rcpp::as<std::string>(nms[i]);
            Rcpp::XPtr<apm::CohortWeightEstimates> xp(cohort_weights_by_spec[i]);
            w_map.emplace(std::move(key), *xp);
        }
    }

    // Union of keys and symmetric validation (mirror build_return_list)
    std::set<std::string> union_keys;
    for (const auto& kv : fact_map) union_keys.insert(kv.first);
    for (const auto& kw : w_map) union_keys.insert(kw.first);

    for (const auto& key : union_keys) {
        if (fact_map.find(key) == fact_map.end()) {
            Rcpp::stop("Spec key present in cohort weights but missing in factor estimates: " + key);
        }
        if (w_map.find(key) == w_map.end()) {
            Rcpp::stop("Spec key present in factor estimates but missing in cohort weights: " + key);
        }
    }

    apm::ObservedOutcomeIndices obs_idx = apm::r_utils::to_cpp_observed_outcome_indices(observed_outcome_indices);
    auto out_map = apm::aggregate_cohort_specific_factor_model_params(fact_map, obs_idx, w_map);

    // Return named list of XPtr<FactorModelEstimates>
    Rcpp::List out(static_cast<int>(out_map.size()));
    Rcpp::CharacterVector names(static_cast<int>(out_map.size()));
    int k = 0;
    for (const auto& kv : out_map) {
        names[k] = kv.first;
        out[k] = make_xptr(apm::FactorModelEstimates(kv.second));
        ++k;
    }
    out.attr("names") = names;
    return out;
}
